# Atlas onboarding
Alice owns the Atlas customer portal. The release is planned for Friday.
Use the project service for current project information.
