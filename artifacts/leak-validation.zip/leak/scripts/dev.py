#!/usr/bin/env python3
"""Run both lab services in the foreground; Ctrl+C stops both."""
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    env = os.environ.copy()
    if (ROOT / ".env").exists():
        for line in (ROOT / ".env").read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                env.setdefault(key.strip(), value.strip())
    jar = ROOT / "backend/target/target-backend-1.0.0.jar"
    python = ROOT / ".venv/bin/python"
    if not jar.exists() or not python.exists():
        sys.exit("Run `make setup` first.")
    env["LAB_FILES"] = str(ROOT / "fixtures/files")
    env["LAB_FIXTURES"] = str(ROOT / "fixtures")
    env["BIND_HOST"] = "127.0.0.1"
    children = []
    def stop(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)
    try:
        children.append(subprocess.Popen(["java", "-jar", str(jar)], cwd=ROOT, env=env))
        children.append(subprocess.Popen([str(python), "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8090"], cwd=ROOT / "agent", env=env))
        print("Backend http://127.0.0.1:8080 | Agent http://127.0.0.1:8090/docs", flush=True)
        while all(child.poll() is None for child in children):
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
        for child in children:
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
    return max((child.returncode or 0 for child in children), default=0)


if __name__ == "__main__":
    sys.exit(main())
