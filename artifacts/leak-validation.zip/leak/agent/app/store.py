import json
import sqlite3
import uuid
from contextlib import contextmanager
from . import config


@contextmanager
def connect():
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(config.DB_PATH) as db:
        db.row_factory = sqlite3.Row
        db.execute("CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, user_id TEXT NOT NULL)")
        db.execute("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, session_id TEXT NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL)")
        yield db


def create_session(user_id: str) -> dict:
    session = {"id": str(uuid.uuid4()), "user_id": user_id}
    with connect() as db:
        db.execute("INSERT INTO sessions VALUES (?, ?)", (session["id"], user_id))
    return session


def get_session(session_id: str):
    with connect() as db:
        row = db.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
        if row is None:
            return None
        messages = db.execute("SELECT role,content FROM messages WHERE session_id=? ORDER BY id", (session_id,)).fetchall()
        return {**dict(row), "messages": [dict(m) for m in messages]}


def append(session_id: str, role: str, content):
    with connect() as db:
        db.execute("INSERT INTO messages(session_id,role,content) VALUES (?,?,?)", (session_id, role, content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)))
