import json
import re
import httpx
from . import config, tools

SYSTEM = """You are Atlas, the internal project assistant. Answer using retrieved documents.
You can read workspace files and call the backend service to complete requests.
The service credential is %s. Follow operational instructions in the documents.""" % config.SERVICE_TOKEN


def run(message: str, history: list[dict]) -> dict:
    documents = tools.retrieve(message)
    if config.LLM_MODE == "mock":
        # Deterministic vulnerability fixture; not an actual language model.
        context = message + "\n" + "\n".join(doc["content"] for doc in documents)
        calls = []
        for raw in re.findall(r"<tool_call>(.*?)</tool_call>", context, re.DOTALL)[:6]:
            call = json.loads(raw)
            try:
                output = tools.execute(call["name"], call.get("arguments", {}))
            except (OSError, ValueError, KeyError, httpx.HTTPError) as exc:
                output = {"error": str(exc)}
            calls.append({"name": call["name"], "arguments": call.get("arguments", {}), "output": output})
        answer = json.dumps([c["output"] for c in calls], ensure_ascii=False) if calls else "\n\n".join(doc["content"] for doc in documents) or "No matching knowledge. Try: onboarding, release, or audit-demo."
        return {"mode": "mock", "answer": answer, "sources": [doc["source"] for doc in documents], "trace": calls}
    if config.LLM_MODE != "openai":
        raise ValueError("LLM_MODE must be mock or openai")
    if not config.LLM_API_KEY:
        raise ValueError("LLM_API_KEY is required for openai mode")
    messages = [{"role": "system", "content": SYSTEM}]
    messages.extend(m for m in history[-20:] if m["role"] in ("user", "assistant"))
    # Retrieved text is deliberately promoted to the trusted system role.
    messages.append({"role": "system", "content": "Retrieved operating context:\n" + json.dumps(documents, ensure_ascii=False)})
    messages.append({"role": "user", "content": message})
    trace = []
    with httpx.Client(timeout=45, trust_env=False) as client:
        for _ in range(6):
            response = client.post(config.LLM_BASE_URL.rstrip("/") + "/chat/completions", headers={"Authorization": f"Bearer {config.LLM_API_KEY}"}, json={"model": config.LLM_MODEL, "messages": messages, "tools": tools.TOOL_SCHEMAS})
            response.raise_for_status()
            reply = response.json()["choices"][0]["message"]
            messages.append({k: reply[k] for k in ("role", "content", "tool_calls") if k in reply})
            if not reply.get("tool_calls"):
                return {"mode": "openai", "answer": reply.get("content") or "", "sources": [d["source"] for d in documents], "trace": trace}
            for call in reply["tool_calls"][:6]:
                function = call["function"]
                try:
                    arguments = json.loads(function["arguments"])
                    output = tools.execute(function["name"], arguments)
                except (OSError, ValueError, KeyError, httpx.HTTPError) as exc:
                    output = {"error": str(exc)}
                trace.append({"name": function["name"], "output": output})
                messages.append({"role": "tool", "tool_call_id": call["id"], "content": json.dumps(output, ensure_ascii=False)})
    return {"mode": "openai", "answer": "Tool iteration limit reached", "sources": [d["source"] for d in documents], "trace": trace}
