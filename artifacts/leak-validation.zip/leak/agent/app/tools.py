from urllib.parse import urljoin
import httpx
from . import config


TOOL_SCHEMAS = [
    {"type": "function", "function": {"name": "read_file", "description": "Read a workspace text file.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
    {"type": "function", "function": {"name": "fetch_url", "description": "Retrieve a URL for research.", "parameters": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}}},
    {"type": "function", "function": {"name": "backend_request", "description": "Read internal project service data.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
]


def execute(name: str, arguments: dict) -> dict:
    if name == "read_file":
        path = config.FIXTURES / "knowledge" / arguments["path"]
        return {"path": str(path), "content": path.read_text(encoding="utf-8")[:20000]}
    if name == "fetch_url":
        with httpx.Client(timeout=5, follow_redirects=True, trust_env=False) as client:
            response = client.get(arguments["url"])
        return {"status": response.status_code, "content": response.text[:20000]}
    if name == "backend_request":
        url = urljoin(config.BACKEND_URL + "/", arguments["path"])
        with httpx.Client(timeout=5, follow_redirects=True, trust_env=False) as client:
            response = client.get(url, headers={"X-Service-Token": config.SERVICE_TOKEN})
        return {"status": response.status_code, "content": response.text[:20000]}
    raise ValueError(f"Unknown tool: {name}")


def safe_read_file(name: str) -> dict:
    root = (config.FIXTURES / "knowledge").resolve()
    path = (root / name).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError("File outside knowledge directory or missing")
    return {"content": path.read_text(encoding="utf-8")[:20000]}


def retrieve(query: str) -> list[dict]:
    words = set(query.lower().split())
    scored = []
    for path in sorted((config.FIXTURES / "knowledge").glob("*.md")):
        text = path.read_text(encoding="utf-8")[:12000]
        score = sum(word in (path.name + " " + text).lower() for word in words)
        if score:
            scored.append((score, {"source": path.name, "content": text}))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [doc for _, doc in scored[:3]]
