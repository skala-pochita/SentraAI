import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FIXTURES = Path(os.getenv("LAB_FIXTURES", str(ROOT / "fixtures")))
DB_PATH = Path(os.getenv("AGENT_DB", str(ROOT / ".runtime" / "agent.sqlite3")))
BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8080")
SERVICE_TOKEN = os.getenv("SERVICE_TOKEN", "lab-agent-service-token")
LLM_MODE = os.getenv("LLM_MODE", "mock")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4.1-mini")
