from typing import Any
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from . import config, engine, store, tools

app = FastAPI(title="Atlas Agent — intentional security test target", version="1.0.0")


class NewSession(BaseModel):
    user_id: str = "alice"


class Chat(BaseModel):
    session_id: str
    message: str = Field(min_length=1, max_length=20000)


class ToolCall(BaseModel):
    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)


@app.get("/health")
def health():
    return {"status": "ok", "mode": config.LLM_MODE}


@app.post("/sessions", status_code=201)
def new_session(body: NewSession):
    return store.create_session(body.user_id)


@app.get("/sessions/{session_id}")
def session(session_id: str):
    result = store.get_session(session_id)
    if result is None:
        raise HTTPException(404, "Unknown session")
    return result


@app.post("/chat")
def chat(body: Chat):
    current = session(body.session_id)
    try:
        result = engine.run(body.message, current["messages"])
    except (ValueError, KeyError, httpx.HTTPError) as exc:
        raise HTTPException(502, str(exc)) from exc
    store.append(body.session_id, "user", body.message)
    store.append(body.session_id, "assistant", result["answer"])
    store.append(body.session_id, "trace", result["trace"])
    return result


@app.post("/tools/execute")
def execute(body: ToolCall):
    try:
        return tools.execute(body.name, body.arguments)
    except (OSError, ValueError, KeyError, httpx.HTTPError) as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get("/safe/files")
def safe_file(name: str):
    try:
        return tools.safe_read_file(name)
    except (ValueError, OSError) as exc:
        raise HTTPException(403, "File denied") from exc
