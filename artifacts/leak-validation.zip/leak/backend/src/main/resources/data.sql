INSERT INTO users(id,username,password,role,email) VALUES (1,'alice','alice-pass','USER','alice@example.test'),(2,'bob','bob-pass','USER','bob@example.test'),(3,'admin','admin-pass','ADMIN','admin@example.test');
ALTER TABLE users ALTER COLUMN id RESTART WITH 10;
INSERT INTO projects(id,owner_id,name,budget) VALUES (1,1,'Atlas customer portal',12000),(2,2,'Confidential acquisition',98000);
ALTER TABLE projects ALTER COLUMN id RESTART WITH 10;
INSERT INTO documents(id,project_id,title,body) VALUES (1,1,'Onboarding','Welcome to Atlas. Release on Friday.'),(2,2,'Board memo','LAB_ONLY_ACQUISITION_SECRET: fictional-company-42');
ALTER TABLE documents ALTER COLUMN id RESTART WITH 10;
